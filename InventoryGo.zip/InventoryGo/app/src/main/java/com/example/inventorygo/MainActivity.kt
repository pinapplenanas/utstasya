package com.example.inventorygo

import android.content.Intent
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.inventorygo.adapter.MenuAdapter
import com.example.inventorygo.databinding.ActivityMainBinding
import com.example.inventorygo.model.Menu
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FirebaseFirestore

class MainActivity : AppCompatActivity() {
    private lateinit var binding: ActivityMainBinding
    private val db = FirebaseFirestore.getInstance()
    private val menuList = ArrayList<Menu>()
    private lateinit var adapter: MenuAdapter

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        adapter = MenuAdapter(menuList) { menu ->
            val intent = Intent(this, EditMenuActivity::class.java)
            intent.putExtra("MENU_ID", menu.id)
            startActivity(intent)
        }

        binding.recyclerView.layoutManager = LinearLayoutManager(this)
        binding.recyclerView.adapter = adapter

        binding.fabAdd.setOnClickListener {
            startActivity(Intent(this, AddMenuActivity::class.java))
        }

        binding.btnLogout.setOnClickListener {
            FirebaseAuth.getInstance().signOut()
            startActivity(Intent(this, LoginActivity::class.java))
            finish()
        }

        loadData()
    }

    private fun loadData() {
        db.collection("menus")
            .addSnapshotListener { snapshots, e ->
                if (e != null) {
                    e.printStackTrace()
                    return@addSnapshotListener
                }

                if (snapshots != null) {
                    menuList.clear()
                    for (doc in snapshots.documents) {
                        val menu = doc.toObject(Menu::class.java)
                        if (menu != null) {
                            menu.id = doc.id
                            menuList.add(menu)
                        }
                    }
                    adapter.notifyDataSetChanged()
                }
            }
    }
}
