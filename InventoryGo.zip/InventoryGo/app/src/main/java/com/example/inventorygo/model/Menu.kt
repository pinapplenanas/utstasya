package com.example.inventorygo.model

data class Menu(
    var id: String? = null,
    var name: String? = null,
    var stock: Int = 0,
    var price: Double = 0.0
)