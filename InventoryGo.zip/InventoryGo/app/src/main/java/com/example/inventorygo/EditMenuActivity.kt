package com.example.inventorygo

import android.os.Bundle
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.example.inventorygo.databinding.ActivityEditMenuBinding
import com.google.firebase.firestore.FirebaseFirestore

class EditMenuActivity : AppCompatActivity() {
    private lateinit var binding: ActivityEditMenuBinding
    private val db = FirebaseFirestore.getInstance()
    private var menuId: String? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityEditMenuBinding.inflate(layoutInflater)
        setContentView(binding.root)

        menuId = intent.getStringExtra("MENU_ID")
        loadMenu()

        binding.btnUpdate.setOnClickListener { updateMenu() }
        binding.btnDelete.setOnClickListener { deleteMenu() }
    }

    private fun loadMenu() {
        db.collection("menus").document(menuId!!).get().addOnSuccessListener {
            binding.etName.setText(it.getString("name"))
            binding.etStock.setText(it.getLong("stock")?.toString())
            binding.etPrice.setText(it.getDouble("price")?.toString())
        }
    }

    private fun updateMenu() {
        val data = mapOf(
            "name" to binding.etName.text.toString(),
            "stock" to binding.etStock.text.toString().toInt(),
            "price" to binding.etPrice.text.toString().toDouble()
        )
        db.collection("menus").document(menuId!!).update(data).addOnSuccessListener {
            Toast.makeText(this, "Menu diperbarui", Toast.LENGTH_SHORT).show()
            finish()
        }
    }

    private fun deleteMenu() {
        db.collection("menus").document(menuId!!).delete().addOnSuccessListener {
            Toast.makeText(this, "Menu dihapus", Toast.LENGTH_SHORT).show()
            finish()
        }
    }
}