package com.example.inventorygo

import android.os.Bundle
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.example.inventorygo.databinding.ActivityAddMenuBinding
import com.example.inventorygo.model.Menu
import com.google.firebase.firestore.FirebaseFirestore

class AddMenuActivity : AppCompatActivity() {
    private lateinit var binding: ActivityAddMenuBinding
    private val db = FirebaseFirestore.getInstance()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityAddMenuBinding.inflate(layoutInflater)
        setContentView(binding.root)

        binding.btnSave.setOnClickListener {
            val name = binding.etName.text.toString()
            val stock = binding.etStock.text.toString().toIntOrNull() ?: 0
            val price = binding.etPrice.text.toString().toDoubleOrNull() ?: 0.0

            val menu = Menu(name = name, stock = stock, price = price)
            db.collection("menus").add(menu).addOnSuccessListener {
                Toast.makeText(this, "Menu ditambahkan", Toast.LENGTH_SHORT).show()
                finish()
            }
        }
    }
}